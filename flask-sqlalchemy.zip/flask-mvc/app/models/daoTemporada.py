from psycopg2 import connect
from app.models.serverDao import db

class TemporadaDAO(DAO):
    def __init__(self):
        super().__init__()    
    def inserir(self, temporada):
        try: 
            with connect(self._dados_con) as conn:
                cur = conn.cursor()
                cur.execute('insert into temporada(numero) values (%s)',[temporada.numero])
                conn.commit()
                cur.close()
                return "Inserido com sucesso!"
        except BaseException as e:
            print ("Problema no inserir -- exception seguindo para ser tratada")
            raise e


        if usuario.persistido():
            self.alterar(usuario)
        else:
            self.inserir(usuario)