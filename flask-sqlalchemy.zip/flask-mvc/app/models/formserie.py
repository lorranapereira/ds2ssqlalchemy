from flask_wtf import FlaskForm
from wtforms import SubmitField,StringField,DecimalField,RadioField,PasswordField,TextAreaField,IntegerField,HiddenField
from wtforms.validators import DataRequired,Optional, Length
from wtforms_components import EmailField
from flask_bootstrap import Bootstrap
from flask_babel import Babel
class formSerie(FlaskForm):
    titulo = StringField('título da série',validators=[DataRequired()])
    numero = IntegerField('número de temporadas',validators=[DataRequired()])
    tituloep = StringField('título do episódio',validators=[DataRequired()])
    numeroep = IntegerField('número do episódio',validators=[DataRequired()])
    enviar = SubmitField('Enviar')
