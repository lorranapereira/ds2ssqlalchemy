class Episodio:
    def __init__(self, titulo, numero, descricao = None,FK_serie_cod,FK_temporada_cod,cod = None):
        self._numero = numero
        self._cod = cod
        self._titulo = titulo
        self._FK_serie_cod = FK_serie_cod
        self._FK_temporada_cod = FK_temporada_cod
    def _get_titulo(self):
        return self._titulo
    def _set_titulo(self, titulo):
        self._titulo = titulo
    def _get_FK_temporada_cod(self):
        return self._FK_temporada_cod
    def _set_FK_temporada_cod(self, FK_temporada_cod):
        self._FK_temporada_cod = FK_temporada_cod
    def _get_cod(self):
        return self._cod
    def _set_cod(self, cod):
        self._cod = cod
    def _get_FK_serie_cod(self):
        return self._FK_serie_cod
    def _set_FK_serie_cod(self, FK_serie_cod):
        self._FK_serie_cod = FK_serie_cod
    def _get_numero(self):
        return self._numero
    def _set_numero(self, numero):
        self._numero = numero
    def __str__(self):
        return "Codigo: {}, numero: {},Titulo: {},FK_serie_cod:{},FK_temporada_cod:{}".format(self.cod,self.numero,self.descricao)
        
    titulo = property( _get_titulo, _set_titulo)
    numero = property( _get_numero, _set_numero)
    FK_serie_cod = property( _get_FK_serie_cod, _set_FK_serie_cod)
    FK_temporada_cod = property( _get_FK_temporada_cod, _set_FK_temporada_cod)
    cod = property( _get_cod, _set_cod)
