from psycopg2 import connect
from app.models.serverDao import db
from app.models.usuario import Usuario

class UsuarioDAO(DAO):
    def __init__(self):
        super().__init__()
    def excluir(self, usuario):
        try: 
            with connect(self._dados_con) as conn:
                cur = conn.cursor()
                cur.execute("DELETE FROM usuario WHERE codigo = %s",[usuario.codigo])
                conn.commit()
                cur.close()
        except BaseException as e:
            print ("Problema no inserir -- exception seguindo para ser tratada")
            raise e
    def buscar(self, cod):
        try: 
            with connect(self._dados_con) as conn:
                cur = conn.cursor()
                cur.execute('SELECT * FROM usuario WHERE codigo = %s', [cod])
                row = cur.fetchone()
                usuario = Usuario(codigo=row[0],nome=row[1],altura=row[2],email=row[3],idade=row[4],senha=row[6],login=row[7])
                cur.close()
                return usuario
        except BaseException as e:
            print ("Problema no buscar -- exception seguindo para ser tratada")
            raise e  
    def verificar(self, login,senha):
        try: 
            with connect(self._dados_con) as conn:
                cur = conn.cursor()
                cur.execute('SELECT nome FROM usuario WHERE login = %s and senha = %s', [login,senha])
                row = cur.fetchone()
                cur.close()
                return row
        except BaseException as e:
            print ("Problema no buscar -- exception seguindo para ser tratada")
            raise e    
    def listar(self):
        vet = []
        try: 
            with connect(self._dados_con) as conn:
                cur = conn.cursor()
                cur.execute('SELECT * FROM usuario')
                for row in cur.fetchall():
                    vet.append(usuario(codigo=row[0],nome=row[1],altura=row[2],sexo=row[3],idade=row[4],biografia=row[5],senha=row[6],login=row[7]))
                cur.close()
        except BaseException as e:
            print ("Problema no listar -- exception seguindo para ser tratada")
            raise e    
        return vet
    def inserir(self, usuario):
        from app.models.serverDao import DAO
        try: 
            with connect(self._dados_con) as conn:
                cur = conn.cursor()
                cur.execute('insert into usuario(nome,seriecod,altura,idade,email,senha,login) values (%s, %s, %s, %s, %s, %s, %s)',[usuario.nome,usuario.seriecod,usuario.altura,usuario.idade,usuario.email,usuario.senha,usuario.login])
                conn.commit()
                cur.close()
                return "Inserido com sucesso!"
        except BaseException as e:
            print ("Problema no inserir -- exception seguindo para ser tratada")
            raise e
    def alterar(self, usuario):
        from app.models.serverDao import DAO
        try: 
            with connect(self._dados_con) as conn:
                cur = conn.cursor()
                cur.execute("UPDATE usuario SET nome=%s, altura=%s, sexo=%s, idade=%s, biografia=%s, senha=%s, login=%s WHERE codigo = %s", [usuario.nome,usuario.altura,usuario.email,usuario.idade,usuario.senha,usuario.login,usuario.codigo])
                conn.commit()
                cur.close()
        except BaseException as e:
            print ("Problema no alterar -- exception seguindo para ser tratada")
            raise e
    def salvar(self, usuario):

        if usuario.persistido():
            self.alterar(usuario)
        else:
            self.inserir(usuario)